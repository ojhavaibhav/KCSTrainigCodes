﻿using System;
using System.Collections;


namespace dependInjectionCode
{

    //constructor injection
   public  interface Ione
    {
        void normal();
    }

    class two : Ione
    {
        public void normal()
        {

            Console.WriteLine("this is normal method of class two");
        }
    }
    class three : Ione
    {
        public void normal()
        {
            Console.WriteLine("this is normal method of class three");
        }
    }

    public class ConstructorInjection
    {
        private Ione intrface;


        public ConstructorInjection(Ione intrface)
        {

            
                this.intrface = intrface;
        }
        public void demo()
        {
            intrface.normal();

        }


    }

    // Property Injection
    public interface Itwo
    {
        void DemoPropInjection(string message);
    }

    class LogWriterClass : Itwo
    {
        public void DemoPropInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass - Property Injection.");
        }
    }
    class LogWriterClass2 : Itwo
    {
        public void DemoPropInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass2 - Property Injection.");
        }
    }
    class PropertyInjectionClass
    {
        Itwo _i2 = null;
        public void DemoPropertyInjectionFunctionOfClass(Itwo _i2, string messages)
        {
            this._i2 = _i2;
            _i2.DemoPropInjection(messages);
        }
    }

    // Method Injection Demo.
    public interface Ithree
    {
        void Demo3();
    }

    // Service Class
    public class ServiceClass : Ithree
    {
        public void Demo3()
        {
            Console.WriteLine("Demo3 Method Overriding - Service Class.");
        }
    }

    // Client Class
    public class ClientClass
    {
        private Ithree _i3;
        public void ClientClassMethod(Ithree _i3)
        {
            this._i3 = _i3;
            Console.WriteLine("Client Class Method Statement Called.");
            this._i3.Demo3();
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            //contructor injection object creation argument passing
            ConstructorInjection c1 = null;
            c1 = new ConstructorInjection(new two());
            c1.demo();
            c1 = new ConstructorInjection(new three());
            c1.demo();

            // Property InjectionClass Object Creates.
            PropertyInjectionClass PIC = new PropertyInjectionClass();
            
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass(), "Message - Property Value Passed.");
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass2(), "Message - Property Value Passed.");

            //Method Injection
            ClientClass CCLS = new ClientClass();
            CCLS.ClientClassMethod(new ServiceClass());


        }
    }
}
