function externalPrompt(){
    var fName = prompt("enter your first name");
    var lName = prompt("enter your last name");
    alert(fName+ " " + lName);
}