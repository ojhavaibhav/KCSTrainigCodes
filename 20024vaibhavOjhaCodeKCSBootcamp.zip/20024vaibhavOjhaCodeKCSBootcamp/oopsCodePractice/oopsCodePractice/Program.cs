﻿using System;

namespace oopsCodePractice
{

    //Inheritance Polymorphism and Encapsulation concepts of Object Oriented Programmimg
    class vehicle
    {
        public int model = 2020;
        public string brand = "BMW";
        public void throttle()
        {
            Console.WriteLine("humm humm!!");
        }

        public void throttle(int a)
        {
            Console.WriteLine("Model no is" + a);
        }

        public void throttle(int a, int b)
        {
            Console.WriteLine("Model no is" + a + " " + b);
        }
    }



    class suzuki : vehicle
    {
        public string color = "yellow";
        public int engineNo = 1000;      

    }



    class bajaj : suzuki
    {
        public int price = 20000;
    }

    //Abstraction concepts
    abstract class father
    {
        public void normal ()
        {
            Console.WriteLine("normal class is here!!");
        }
        public abstract void fatherDetails();
    }
     class son : father
    {
        public override void fatherDetails()
        {
            Console.WriteLine("details of son are here!!");
        }
    }

    //Interface

    interface Iapple
    {
        void type();
    }
    interface Iorange
    {
        void des();

    }
    class demoFruit : Iapple, Iorange
    {
        public void type()
        {
            Console.WriteLine("it is an apple");
        }
        public void des()
        {
            Console.WriteLine("it is an orange");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {

            //inheritance, polymorphism, encapsulation
            vehicle veh = new vehicle();
            bajaj ba = new bajaj(); 
            suzuki su = new suzuki();

            Console.WriteLine("Brand of my car is "+ veh.brand);
            Console.WriteLine("Brand of my car is " + su.model);
            ba.throttle();


            // abstraction 
            son so = new son();
            so.normal();
            so.fatherDetails();

            //iterface
            demoFruit df = new demoFruit(); 
            df.type();
            df.des();

        }
    }
}
